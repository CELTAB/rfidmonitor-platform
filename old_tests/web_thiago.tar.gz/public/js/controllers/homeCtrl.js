angular.module("rfidplatform").controller("homeCtrl", function($scope){

	$scope.app = "Home page";

});